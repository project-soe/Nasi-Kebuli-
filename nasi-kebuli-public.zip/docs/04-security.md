# 04 - Keamanan

Perlindungan data ada di `firebase/firestore.rules` dan Firebase Authentication, bukan di
kode browser. Konfigurasi web Firebase (apiKey dll.) memang publik.

## Harga pesanan tidak dipercaya dari browser
Saat pesanan dibuat, aturan Firestore memeriksa SETIAP baris terhadap dokumen menu:
- `id` harus ada di koleksi `menu`, menu tersedia
- `price` dan `name` harus sama persis dengan menu (mencegah menukar harga/nama)
- `qty` bilangan bulat 1-20
- `total` harus sama dengan jumlah (price x qty) seluruh baris
- maksimal 6 jenis menu per pesanan (aturan tidak punya perulangan; batas ini juga menjaga
  jumlah pembacaan dokumen di bawah batas 10 per permintaan)
- toko harus buka; nomor HP berformat 08xxxxxxxxxx

Bila harga menu berubah saat pelanggan sedang checkout, server menolak; halaman checkout
otomatis menyelaraskan keranjang dan meminta pelanggan mengirim ulang.

## Data pribadi
- `orders` (nama, HP, catatan): hanya admin yang bisa membaca (get/list/update/delete).
- Pelanggan memantau status lewat `orderStatus/{id}`: salinan TANPA data pribadi, hanya bisa
  dibaca bila tahu ID acaknya (20 karakter acak dari Firestore). Ini "tautan rahasia":
  bukan otorisasi per akun, tetapi isinya tidak memuat identitas pelanggan.
- Dokumen `orderStatus` hanya bisa dibuat bersamaan dengan pesanan yang lolos validasi.

## Admin
- Admin = akun Firebase Auth yang punya dokumen `admins/{uid}` (dibuat manual di Console).
- Hanya admin yang bisa mengubah menu, pengaturan toko, dan status pesanan.

## Spam pesanan: Firebase App Check
Aturan Firestore tidak bisa membatasi frekuensi, dan konfigurasi Firebase di situs bersifat publik,
sehingga skrip dapat memanggil Firestore langsung tanpa membuka situs. App Check menolak permintaan
yang tidak membawa bukti berasal dari situs asli (reCAPTCHA v3). Gratis, tanpa Cloud Functions.

### Mengaktifkan App Check (urutan penting)
1. Buka https://www.google.com/recaptcha/admin/create > jenis **reCAPTCHA v3**.
   Domain: `project-soe.github.io` dan `localhost`. Simpan **Site key** dan **Secret key**.
2. Firebase Console > **App Check** > tab Apps > pilih aplikasi web > reCAPTCHA > tempel
   **Secret key** > Save. (Secret key HANYA di Console, jangan di kode.)
3. Isi **Site key** di `public/js/core/firebase-config.js` pada `appCheckConfig.siteKey`.
   Commit dan push, tunggu GitHub Pages selesai.
4. Buka situs, telusuri menu dan buat satu pesanan uji. Di Console > App Check > **APIs** >
   Cloud Firestore, lihat grafik: permintaan "Verified" harus muncul.
5. Baru setelah itu tekan **Enforce** pada Cloud Firestore. Bila ada yang rusak, tekan
   Unenforce (bisa dibatalkan kapan saja).
6. Pengembangan lokal: domain `localhost` sudah didaftarkan di langkah 1, jadi biasanya langsung
   jalan. Bila ditolak, buat token debug sendiri:
   `python3 -c "import uuid; print(uuid.uuid4())"`, daftarkan di App Check > Manage debug tokens,
   lalu buka sekali `http://localhost:8080/?appcheck_debug=<token>` di browser HP itu.
   JANGAN menulis token debug di kode atau repo.

## Yang BELUM dicegah (diketahui)
- Pengunjung nyata yang sengaja mengirim banyak pesanan. App Check hanya menyaring bot/skrip.
  Pemilik tetap memeriksa pesanan sebelum menekan Terima.
- Siapa pun yang memegang tautan status dapat melihat isi dan status pesanan itu.

## Praktik
- Jangan commit: file service account (*.json berisi private_key), .env.
- Semua teks dari database ditampilkan lewat textContent (anti XSS).
- Setelah mengubah `firestore.rules`, tempel ulang di Console lalu Publish.
